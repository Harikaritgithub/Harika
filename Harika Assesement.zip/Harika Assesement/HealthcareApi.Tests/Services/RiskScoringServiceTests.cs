using Xunit;
using FluentAssertions;
using HealthcareApi.Services;
using HealthcareApi.Models;

namespace HealthcareApi.Tests.Services
{
    public class RiskScoringServiceTests
    {
        private readonly RiskScoringService _riskScoringService;

        public RiskScoringServiceTests()
        {
            _riskScoringService = new RiskScoringService();
        }

        #region Blood Pressure Risk Tests

        [Theory]
        [InlineData("110/70", 1)] // Normal
        [InlineData("119/79", 1)] // Normal
        [InlineData("120/70", 2)] // Elevated (systolic 120-129, diastolic <80)
        [InlineData("125/75", 2)] // Elevated
        [InlineData("129/79", 2)] // Elevated
        [InlineData("130/70", 3)] // Stage 1 (systolic 130-139)
        [InlineData("135/85", 3)] // Stage 1 (diastolic 80-89)
        [InlineData("139/89", 3)] // Stage 1
        [InlineData("140/70", 4)] // Stage 2 (systolic ≥140)
        [InlineData("150/95", 4)] // Stage 2 (diastolic ≥90)
        public void CalculateBloodPressureRisk_ValidReadings_ReturnsCorrectRisk(string bloodPressure, int expectedRisk)
        {
            // Act
            var result = _riskScoringService.CalculateBloodPressureRisk(bloodPressure);

            // Assert
            result.Should().Be(expectedRisk);
        }

        [Theory]
        [InlineData("")]
        [InlineData(null)]
        [InlineData("   ")]
        [InlineData("INVALID")]
        [InlineData("120")]
        [InlineData("120/")]
        [InlineData("/80")]
        [InlineData("120-80")]
        [InlineData("abc/def")]
        public void CalculateBloodPressureRisk_InvalidReadings_ReturnsZero(string bloodPressure)
        {
            // Act
            var result = _riskScoringService.CalculateBloodPressureRisk(bloodPressure);

            // Assert
            result.Should().Be(0);
        }

        [Fact]
        public void CalculateBloodPressureRisk_HigherCategoryWins_ReturnsHigherRisk()
        {
            // Test case where systolic is Stage 1 (130) but diastolic is Stage 2 (95)
            // Should return Stage 2 risk (4)
            var result = _riskScoringService.CalculateBloodPressureRisk("130/95");
            result.Should().Be(4);
        }

        #endregion

        #region Temperature Risk Tests

        [Theory]
        [InlineData(98.6, 0)] // Normal
        [InlineData(99.5, 0)] // Normal (boundary)
        [InlineData(99.6, 1)] // Low fever (boundary)
        [InlineData(100.0, 1)] // Low fever
        [InlineData(100.9, 1)] // Low fever (boundary)
        [InlineData(101.0, 2)] // High fever (boundary)
        [InlineData(102.5, 2)] // High fever
        public void CalculateTemperatureRisk_ValidTemperatures_ReturnsCorrectRisk(double temperature, int expectedRisk)
        {
            // Act
            var result = _riskScoringService.CalculateTemperatureRisk(temperature);

            // Assert
            result.Should().Be(expectedRisk);
        }

        [Fact]
        public void CalculateTemperatureRisk_NullTemperature_ReturnsZero()
        {
            // Act
            var result = _riskScoringService.CalculateTemperatureRisk(null);

            // Assert
            result.Should().Be(0);
        }

        #endregion

        #region Age Risk Tests

        [Theory]
        [InlineData(25, 1)] // Under 40
        [InlineData(39, 1)] // Under 40 (boundary)
        [InlineData(40, 1)] // 40-65 (boundary)
        [InlineData(50, 1)] // 40-65
        [InlineData(65, 1)] // 40-65 (boundary)
        [InlineData(66, 2)] // Over 65
        [InlineData(80, 2)] // Over 65
        public void CalculateAgeRisk_ValidAges_ReturnsCorrectRisk(int age, int expectedRisk)
        {
            // Act
            var result = _riskScoringService.CalculateAgeRisk(age);

            // Assert
            result.Should().Be(expectedRisk);
        }

        [Fact]
        public void CalculateAgeRisk_NullAge_ReturnsZero()
        {
            // Act
            var result = _riskScoringService.CalculateAgeRisk(null);

            // Assert
            result.Should().Be(0);
        }

        #endregion

        #region Total Risk Tests

        [Fact]
        public void CalculateTotalRisk_ValidPatient_ReturnsSumOfAllRisks()
        {
            // Arrange
            var patient = new Patient
            {
                BloodPressure = "140/90", // Risk: 4
                Temperature = 100.5,      // Risk: 1
                Age = 70                  // Risk: 2
            };

            // Act
            var result = _riskScoringService.CalculateTotalRisk(patient);

            // Assert
            result.Should().Be(7); // 4 + 1 + 2
        }

        [Fact]
        public void CalculateTotalRisk_PatientWithInvalidData_ReturnsPartialRisk()
        {
            // Arrange
            var patient = new Patient
            {
                BloodPressure = "INVALID", // Risk: 0
                Temperature = 100.5,       // Risk: 1
                Age = 70                   // Risk: 2
            };

            // Act
            var result = _riskScoringService.CalculateTotalRisk(patient);

            // Assert
            result.Should().Be(3); // 0 + 1 + 2
        }

        #endregion

        #region High Risk Tests

        [Theory]
        [InlineData("140/90", 98.6, 70, true)]  // Total: 4 + 0 + 2 = 6 (≥4)
        [InlineData("130/85", 100.0, 50, true)] // Total: 3 + 1 + 1 = 5 (≥4)
        [InlineData("120/80", 99.0, 30, true)]  // Total: 3 + 0 + 1 = 4 (≥4) - diastolic 80 is Stage 1
        [InlineData("125/82", 98.6, 45, true)]  // Total: 3 + 0 + 1 = 4 (≥4) - diastolic 82 is Stage 1
        [InlineData("115/75", 98.6, 35, false)] // Total: 1 + 0 + 1 = 2 (<4) - truly low risk
        public void IsHighRisk_VariousPatients_ReturnsCorrectResult(string bp, double temp, int age, bool expectedHighRisk)
        {
            // Arrange
            var patient = new Patient
            {
                BloodPressure = bp,
                Temperature = temp,
                Age = age
            };

            // Act
            var result = _riskScoringService.IsHighRisk(patient);

            // Assert
            result.Should().Be(expectedHighRisk);
        }

        #endregion

        #region Fever Tests

        [Theory]
        [InlineData(99.5, false)]
        [InlineData(99.6, true)]
        [InlineData(100.0, true)]
        [InlineData(101.5, true)]
        public void HasFever_VariousTemperatures_ReturnsCorrectResult(double temperature, bool expectedHasFever)
        {
            // Arrange
            var patient = new Patient { Temperature = temperature };

            // Act
            var result = _riskScoringService.HasFever(patient);

            // Assert
            result.Should().Be(expectedHasFever);
        }

        [Fact]
        public void HasFever_NullTemperature_ReturnsFalse()
        {
            // Arrange
            var patient = new Patient { Temperature = null };

            // Act
            var result = _riskScoringService.HasFever(patient);

            // Assert
            result.Should().BeFalse();
        }

        #endregion

        #region Data Quality Tests

        [Theory]
        [InlineData("120/80", 98.6, 45, false)] // All valid
        [InlineData("INVALID", 98.6, 45, true)] // Invalid BP
        [InlineData("", 98.6, 45, true)]        // Empty BP
        [InlineData("120/", 98.6, 45, true)]    // Partial BP
        [InlineData("120/80", null, 45, true)]  // Missing temperature
        [InlineData("120/80", 98.6, null, true)] // Missing age
        public void HasDataQualityIssues_VariousPatients_ReturnsCorrectResult(
            string bp, double? temp, int? age, bool expectedHasIssues)
        {
            // Arrange
            var patient = new Patient
            {
                BloodPressure = bp,
                Temperature = temp,
                Age = age
            };

            // Act
            var result = _riskScoringService.HasDataQualityIssues(patient);

            // Assert
            result.Should().Be(expectedHasIssues);
        }

        [Fact]
        public void HasDataQualityIssues_NullBloodPressure_ReturnsTrue()
        {
            // Arrange
            var patient = new Patient
            {
                BloodPressure = null,
                Temperature = 98.6,
                Age = 45
            };

            // Act
            var result = _riskScoringService.HasDataQualityIssues(patient);

            // Assert
            result.Should().BeTrue();
        }

        #endregion
    }
}