using Xunit;
using FluentAssertions;
using HealthcareApi.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthcareApi.Tests.Services
{
    public class PatientServiceTests
    {
        private readonly PatientService _patientService;

        public PatientServiceTests()
        {
            _patientService = new PatientService();
        }

        #region GetPatientsAsync Tests

        [Fact]
        public async Task GetPatientsAsync_DefaultParameters_ReturnsFirstPageWithFivePatients()
        {
            // Act
            var result = await _patientService.GetPatientsAsync();

            // Assert
            result.Should().NotBeNull();
            result.Data.Should().HaveCount(5);
            result.Pagination.Page.Should().Be(1);
            result.Pagination.Limit.Should().Be(5);
            result.Pagination.HasPrevious.Should().BeFalse();
            result.Pagination.HasNext.Should().BeTrue();
        }

        [Fact]
        public async Task GetPatientsAsync_Page2Limit10_ReturnsCorrectPage()
        {
            // Act
            var result = await _patientService.GetPatientsAsync(page: 2, limit: 10);

            // Assert
            result.Should().NotBeNull();
            result.Data.Should().HaveCount(10);
            result.Pagination.Page.Should().Be(2);
            result.Pagination.Limit.Should().Be(10);
            result.Pagination.HasPrevious.Should().BeTrue();
        }

        [Fact]
        public async Task GetPatientsAsync_LastPage_HasNextShouldBeFalse()
        {
            // Get total count first
            var firstPage = await _patientService.GetPatientsAsync(page: 1, limit: 5);
            var totalPages = firstPage.Pagination.TotalPages;

            // Act - Get last page
            var result = await _patientService.GetPatientsAsync(page: totalPages, limit: 5);

            // Assert
            result.Should().NotBeNull();
            result.Pagination.HasNext.Should().BeFalse();
            result.Pagination.HasPrevious.Should().BeTrue();
        }

        [Theory]
        [InlineData(0, 5, 1, 5)] // Invalid page should default to 1
        [InlineData(-1, 5, 1, 5)] // Negative page should default to 1
        [InlineData(1, 0, 1, 1)] // Invalid limit should default to 1
        [InlineData(1, -5, 1, 1)] // Negative limit should default to 1
        [InlineData(1, 25, 1, 20)] // Limit over 20 should cap at 20
        public async Task GetPatientsAsync_InvalidParameters_UsesValidDefaults(
            int inputPage, int inputLimit, int expectedPage, int expectedLimit)
        {
            // Act
            var result = await _patientService.GetPatientsAsync(inputPage, inputLimit);

            // Assert
            result.Pagination.Page.Should().Be(expectedPage);
            result.Pagination.Limit.Should().Be(expectedLimit);
        }

        [Fact]
        public async Task GetPatientsAsync_Always_ReturnsMetadataWithTimestamp()
        {
            // Act
            var result = await _patientService.GetPatientsAsync();

            // Assert
            result.Metadata.Should().NotBeNull();
            result.Metadata.Timestamp.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(5));
            result.Metadata.Version.Should().Be("v1.0");
            result.Metadata.RequestId.Should().NotBeNullOrEmpty();
            result.Metadata.RequestId.Should().HaveLength(8);
        }

        [Fact]
        public async Task GetPatientsAsync_Always_ReturnsPaginationInfo()
        {
            // Act
            var result = await _patientService.GetPatientsAsync(page: 1, limit: 5);

            // Assert
            result.Pagination.Should().NotBeNull();
            result.Pagination.Total.Should().BeGreaterThan(0);
            result.Pagination.TotalPages.Should().BeGreaterThan(0);
            result.Pagination.TotalPages.Should().Be((int)Math.Ceiling((double)result.Pagination.Total / result.Pagination.Limit));
        }

        #endregion

        #region GetAllPatientsAsync Tests

        [Fact]
        public async Task GetAllPatientsAsync_Always_ReturnsAllPatients()
        {
            // Act
            var result = await _patientService.GetAllPatientsAsync();

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(50); // We expect 50 mock patients
            result.Should().OnlyHaveUniqueItems(p => p.PatientId);
        }

        [Fact]
        public async Task GetAllPatientsAsync_Always_ReturnsValidPatientData()
        {
            // Act
            var result = await _patientService.GetAllPatientsAsync();

            // Assert
            result.Should().NotBeNull();
            result.Should().AllSatisfy(patient =>
            {
                patient.PatientId.Should().NotBeNullOrEmpty();
                patient.Name.Should().NotBeNullOrEmpty();
                patient.Gender.Should().NotBeNullOrEmpty();
                patient.VisitDate.Should().NotBeNullOrEmpty();
                patient.Diagnosis.Should().NotBeNullOrEmpty();
                patient.Medications.Should().NotBeNullOrEmpty();
            });
        }

        #endregion

        #region GetPatientByIdAsync Tests

        [Fact]
        public async Task GetPatientByIdAsync_ExistingPatient_ReturnsPatient()
        {
            // Arrange
            var existingPatientId = "DEMO001";

            // Act
            var result = await _patientService.GetPatientByIdAsync(existingPatientId);

            // Assert
            result.Should().NotBeNull();
            result!.PatientId.Should().Be(existingPatientId);
            result.Name.Should().NotBeNullOrEmpty();
        }

        [Fact]
        public async Task GetPatientByIdAsync_NonExistentPatient_ReturnsNull()
        {
            // Arrange
            var nonExistentPatientId = "NONEXISTENT";

            // Act
            var result = await _patientService.GetPatientByIdAsync(nonExistentPatientId);

            // Assert
            result.Should().BeNull();
        }

        [Theory]
        [InlineData("")]
        [InlineData("   ")]
        [InlineData(null)]
        public async Task GetPatientByIdAsync_InvalidPatientId_ReturnsNull(string patientId)
        {
            // Act
            var result = await _patientService.GetPatientByIdAsync(patientId);

            // Assert
            result.Should().BeNull();
        }

        #endregion

        #region Data Consistency Tests

        [Fact]
        public async Task GetPatientsAsync_MultiplePages_ReturnsAllPatientsWithoutDuplicates()
        {
            // Arrange
            var allPatientIds = new HashSet<string>();
            var pageSize = 10;
            var currentPage = 1;
            bool hasMore = true;

            // Act - Get all patients through pagination
            while (hasMore)
            {
                var result = await _patientService.GetPatientsAsync(currentPage, pageSize);
                
                foreach (var patient in result.Data)
                {
                    allPatientIds.Add(patient.PatientId);
                }

                hasMore = result.Pagination.HasNext;
                currentPage++;
            }

            // Assert
            var allPatientsDirectly = await _patientService.GetAllPatientsAsync();
            allPatientIds.Should().HaveCount(allPatientsDirectly.Count);
            allPatientIds.Should().BeEquivalentTo(allPatientsDirectly.Select(p => p.PatientId));
        }

        [Fact]
        public async Task PatientService_MockData_ContainsExpectedTestCases()
        {
            // Act
            var allPatients = await _patientService.GetAllPatientsAsync();

            // Assert - Verify we have patients for different test scenarios
            allPatients.Should().Contain(p => p.PatientId == "DEMO001"); // Normal patient
            allPatients.Should().Contain(p => p.PatientId == "DEMO002"); // High-risk patient
            allPatients.Should().Contain(p => p.PatientId == "DEMO004"); // Data quality issues
            allPatients.Should().Contain(p => p.PatientId == "DEMO005"); // Fever patient

            // Verify we have patients with various data quality issues
            allPatients.Should().Contain(p => p.BloodPressure == "INVALID");
            allPatients.Should().Contain(p => p.Temperature == null);
            allPatients.Should().Contain(p => p.Age == null);
        }

        #endregion

        #region Performance Tests

        [Fact]
        public async Task GetPatientsAsync_LargePageSize_CompletesInReasonableTime()
        {
            // Arrange
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            // Act
            var result = await _patientService.GetPatientsAsync(page: 1, limit: 20);

            // Assert
            stopwatch.Stop();
            stopwatch.ElapsedMilliseconds.Should().BeLessThan(1000); // Should complete within 1 second
            result.Data.Should().HaveCount(20);
        }

        [Fact]
        public async Task GetAllPatientsAsync_CompletesInReasonableTime()
        {
            // Arrange
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            // Act
            var result = await _patientService.GetAllPatientsAsync();

            // Assert
            stopwatch.Stop();
            stopwatch.ElapsedMilliseconds.Should().BeLessThan(1000); // Should complete within 1 second
            result.Should().HaveCount(50);
        }

        #endregion
    }
}