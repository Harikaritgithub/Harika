using Microsoft.AspNetCore.Mvc.Testing;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using Xunit;
using FluentAssertions;
using HealthcareApi.DTOs;

namespace HealthcareApi.Tests.Integration
{
    public class PatientsApiTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly WebApplicationFactory<Program> _factory;
        private readonly HttpClient _client;
        private const string ValidApiKey = "demo-api-key-12345";

        public PatientsApiTests(WebApplicationFactory<Program> factory)
        {
            _factory = factory;
            _client = _factory.CreateClient();
        }

        [Fact]
        public async Task GetPatients_WithoutApiKey_ReturnsUnauthorized()
        {
            // Act
            var response = await _client.GetAsync("/api/patients");

            // Assert
            response.StatusCode.Should().Be(System.Net.HttpStatusCode.Unauthorized);
        }

        [Fact]
        public async Task GetPatients_WithValidApiKey_ReturnsSuccessOrSimulatedFailure()
        {
            // Arrange
            _client.DefaultRequestHeaders.Add("x-api-key", ValidApiKey);

            // Act
            var response = await _client.GetAsync("/api/patients");

            // Assert - Handle both success and simulated failures
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var content = await response.Content.ReadAsStringAsync();
                
                // Handle potential inconsistent response formats
                try
                {
                    var patientResponse = JsonSerializer.Deserialize<PatientResponse>(content, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                    patientResponse.Should().NotBeNull();
                    // Note: Due to inconsistent responses, field names and structure may vary
                    content.Should().NotBeNullOrEmpty();
                }
                catch (JsonException)
                {
                    // This is expected due to inconsistent response formats
                    content.Should().NotBeNullOrEmpty();
                }
            }
            else
            {
                // Simulated failures (500/503) are expected behavior
                response.StatusCode.Should().BeOneOf(
                    System.Net.HttpStatusCode.InternalServerError,
                    System.Net.HttpStatusCode.ServiceUnavailable);
            }
        }

        [Fact]
        public async Task GetPatients_WithPagination_ReturnsCorrectPageOrSimulatedFailure()
        {
            // Arrange
            _client.DefaultRequestHeaders.Add("x-api-key", ValidApiKey);

            // Act
            var response = await _client.GetAsync("/api/patients?page=2&limit=10");

            // Assert - Handle both success and simulated failures
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var content = await response.Content.ReadAsStringAsync();
                
                // Handle potential inconsistent response formats
                try
                {
                    var patientResponse = JsonSerializer.Deserialize<PatientResponse>(content, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                    patientResponse.Should().NotBeNull();
                    // Note: Due to inconsistent responses, we may get different field names or structures
                    // This test validates that we get some form of patient data
                }
                catch (JsonException)
                {
                    // This is expected due to inconsistent response formats
                    content.Should().NotBeNullOrEmpty();
                }
            }
            else
            {
                // Simulated failures (500/503) are expected behavior
                response.StatusCode.Should().BeOneOf(
                    System.Net.HttpStatusCode.InternalServerError,
                    System.Net.HttpStatusCode.ServiceUnavailable);
            }
        }

        [Fact]
        public async Task SubmitAssessment_WithoutApiKey_ReturnsUnauthorized()
        {
            // Arrange
            var request = new AssessmentRequest
            {
                HighRiskPatients = new List<string> { "DEMO002" },
                FeverPatients = new List<string> { "DEMO005" },
                DataQualityIssues = new List<string> { "DEMO004" }
            };

            var json = JsonSerializer.Serialize(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            // Act
            var response = await _client.PostAsync("/api/submit-assessment", content);

            // Assert
            response.StatusCode.Should().Be(System.Net.HttpStatusCode.Unauthorized);
        }

        [Fact]
        public async Task SubmitAssessment_WithValidApiKey_ReturnsSuccessOrSimulatedFailure()
        {
            // Arrange
            _client.DefaultRequestHeaders.Add("x-api-key", ValidApiKey);
            
            var request = new AssessmentRequest
            {
                HighRiskPatients = new List<string> { "DEMO002", "DEMO031" },
                FeverPatients = new List<string> { "DEMO005", "DEMO021" },
                DataQualityIssues = new List<string> { "DEMO004", "DEMO007" }
            };

            var json = JsonSerializer.Serialize(request, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            // Act
            var response = await _client.PostAsync("/api/submit-assessment", content);

            // Assert - Handle both success and simulated failures
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var assessmentResponse = JsonSerializer.Deserialize<AssessmentResponse>(responseContent, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                assessmentResponse.Should().NotBeNull();
                assessmentResponse!.Success.Should().BeTrue();
                assessmentResponse.Results.Should().NotBeNull();
                assessmentResponse.Results.Score.Should().BeGreaterThan(0);
                assessmentResponse.Results.AttemptNumber.Should().Be(1);
            }
            else
            {
                // Simulated failures (500/503) are expected behavior
                response.StatusCode.Should().BeOneOf(
                    System.Net.HttpStatusCode.InternalServerError,
                    System.Net.HttpStatusCode.ServiceUnavailable);
            }
        }

        [Fact]
        public async Task HealthCheck_Always_ReturnsHealthy()
        {
            // Act
            var response = await _client.GetAsync("/health");

            // Assert
            response.StatusCode.Should().Be(System.Net.HttpStatusCode.OK);
            
            var content = await response.Content.ReadAsStringAsync();
            content.Should().Contain("healthy");
        }
    }
}