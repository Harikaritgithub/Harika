namespace HealthcareApi.Models
{
    public class Patient
    {
        public string PatientId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public int? Age { get; set; }
        public string Gender { get; set; } = string.Empty;
        public string BloodPressure { get; set; } = string.Empty;
        public double? Temperature { get; set; }
        public string VisitDate { get; set; } = string.Empty;
        public string Diagnosis { get; set; } = string.Empty;
        public string Medications { get; set; } = string.Empty;
    }
}