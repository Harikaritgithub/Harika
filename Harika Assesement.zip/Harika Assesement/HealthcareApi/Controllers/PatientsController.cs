using Microsoft.AspNetCore.Mvc;
using HealthcareApi.Services;
using HealthcareApi.DTOs;

namespace HealthcareApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PatientsController : ControllerBase
    {
        private readonly IPatientService _patientService;
        private readonly ILogger<PatientsController> _logger;

        public PatientsController(IPatientService patientService, ILogger<PatientsController> logger)
        {
            _patientService = patientService;
            _logger = logger;
        }

        /// <summary>
        /// Retrieve patient list with pagination
        /// </summary>
        /// <param name="page">The page index (default: 1)</param>
        /// <param name="limit">How many resources to return in each list page (default: 5, max: 20)</param>
        /// <returns>Paginated list of patients</returns>
        [HttpGet]
        public async Task<ActionResult<PatientResponse>> GetPatients(
            [FromQuery] int page = 1, 
            [FromQuery] int limit = 5)
        {
            try
            {
                _logger.LogInformation("Retrieving patients - Page: {Page}, Limit: {Limit}", page, limit);
                
                var result = await _patientService.GetPatientsAsync(page, limit);
                
                _logger.LogInformation("Successfully retrieved {Count} patients for page {Page}", 
                    result.Data.Count, page);
                
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving patients - Page: {Page}, Limit: {Limit}", page, limit);
                
                return StatusCode(500, new
                {
                    error = "Internal Server Error",
                    message = "An error occurred while retrieving patients",
                    timestamp = DateTime.UtcNow
                });
            }
        }

        /// <summary>
        /// Get a specific patient by ID
        /// </summary>
        /// <param name="id">Patient ID</param>
        /// <returns>Patient details</returns>
        [HttpGet("{id}")]
        public async Task<ActionResult> GetPatient(string id)
        {
            try
            {
                _logger.LogInformation("Retrieving patient with ID: {PatientId}", id);
                
                var patient = await _patientService.GetPatientByIdAsync(id);
                
                if (patient == null)
                {
                    _logger.LogWarning("Patient not found with ID: {PatientId}", id);
                    return NotFound(new
                    {
                        error = "Not Found",
                        message = $"Patient with ID '{id}' not found",
                        timestamp = DateTime.UtcNow
                    });
                }
                
                _logger.LogInformation("Successfully retrieved patient: {PatientId}", id);
                return Ok(patient);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving patient with ID: {PatientId}", id);
                
                return StatusCode(500, new
                {
                    error = "Internal Server Error",
                    message = "An error occurred while retrieving the patient",
                    timestamp = DateTime.UtcNow
                });
            }
        }
    }
}