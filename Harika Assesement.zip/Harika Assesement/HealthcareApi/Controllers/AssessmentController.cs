using Microsoft.AspNetCore.Mvc;
using HealthcareApi.Services;
using HealthcareApi.DTOs;

namespace HealthcareApi.Controllers
{
    [ApiController]
    [Route("api/submit-assessment")]
    public class AssessmentController : ControllerBase
    {
        private readonly IPatientService _patientService;
        private readonly IRiskScoringService _riskScoringService;
        private readonly ILogger<AssessmentController> _logger;
        private static readonly Dictionary<string, int> _attemptCounts = new();

        public AssessmentController(
            IPatientService patientService, 
            IRiskScoringService riskScoringService,
            ILogger<AssessmentController> logger)
        {
            _patientService = patientService;
            _riskScoringService = riskScoringService;
            _logger = logger;
        }

        /// <summary>
        /// Submit assessment results for scoring
        /// </summary>
        /// <param name="request">Assessment submission with patient ID arrays</param>
        /// <returns>Assessment results with scoring breakdown</returns>
        [HttpPost]
        public async Task<ActionResult<AssessmentResponse>> SubmitAssessment([FromBody] AssessmentRequest request)
        {
            try
            {
                var apiKey = HttpContext.Items["ApiKey"]?.ToString() ?? "unknown";
                
                _logger.LogInformation("Processing assessment submission from API key: {ApiKey}", 
                    apiKey[..Math.Min(8, apiKey.Length)] + "...");

                // Track attempt count
                var attemptNumber = _attemptCounts.GetValueOrDefault(apiKey, 0) + 1;
                _attemptCounts[apiKey] = attemptNumber;

                // Get all patients for evaluation
                var allPatients = await _patientService.GetAllPatientsAsync();
                
                // Calculate correct answers
                var correctHighRisk = allPatients
                    .Where(p => _riskScoringService.IsHighRisk(p))
                    .Select(p => p.PatientId)
                    .ToHashSet();

                var correctFever = allPatients
                    .Where(p => _riskScoringService.HasFever(p))
                    .Select(p => p.PatientId)
                    .ToHashSet();

                var correctDataQuality = allPatients
                    .Where(p => _riskScoringService.HasDataQualityIssues(p))
                    .Select(p => p.PatientId)
                    .ToHashSet();

                // Calculate scores
                var highRiskScore = CalculateCategoryScore(
                    request.HighRiskPatients, correctHighRisk, 50);
                var feverScore = CalculateCategoryScore(
                    request.FeverPatients, correctFever, 25);
                var dataQualityScore = CalculateCategoryScore(
                    request.DataQualityIssues, correctDataQuality, 25);

                var totalScore = highRiskScore.Score + feverScore.Score + dataQualityScore.Score;
                var percentage = (int)Math.Round((double)totalScore / 100 * 100);
                var status = percentage >= 70 ? "PASS" : "FAIL";

                var response = new AssessmentResponse
                {
                    Success = true,
                    Message = "Assessment submitted successfully",
                    Results = new AssessmentResults
                    {
                        Score = Math.Round((double)totalScore, 2),
                        Percentage = percentage,
                        Status = status,
                        Breakdown = new AssessmentBreakdown
                        {
                            HighRisk = highRiskScore,
                            Fever = feverScore,
                            DataQuality = dataQualityScore
                        },
                        Feedback = GenerateFeedback(highRiskScore, feverScore, dataQualityScore),
                        AttemptNumber = attemptNumber,
                        RemainingAttempts = Math.Max(0, 3 - attemptNumber),
                        IsPersonalBest = true, // Simplified for demo
                        CanResubmit = attemptNumber < 3
                    }
                };

                _logger.LogInformation("Assessment completed - Score: {Score}%, Status: {Status}, Attempt: {Attempt}", 
                    percentage, status, attemptNumber);

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing assessment submission");
                
                return StatusCode(500, new AssessmentResponse
                {
                    Success = false,
                    Message = "An error occurred while processing the assessment"
                });
            }
        }

        private CategoryScore CalculateCategoryScore(List<string> submitted, HashSet<string> correct, int maxScore)
        {
            var submittedSet = submitted.ToHashSet();
            var matches = submittedSet.Intersect(correct).Count();
            var correctCount = correct.Count;
            var submittedCount = submitted.Count;

            // Calculate score based on precision and recall
            var precision = submittedCount > 0 ? (double)matches / submittedCount : 0;
            var recall = correctCount > 0 ? (double)matches / correctCount : 0;
            var f1Score = precision + recall > 0 ? 2 * (precision * recall) / (precision + recall) : 0;
            
            var score = (int)Math.Round(f1Score * maxScore);

            return new CategoryScore
            {
                Score = score,
                Max = maxScore,
                Correct = correctCount,
                Submitted = submittedCount,
                Matches = matches
            };
        }

        private AssessmentFeedback GenerateFeedback(CategoryScore highRisk, CategoryScore fever, CategoryScore dataQuality)
        {
            var feedback = new AssessmentFeedback();

            // Generate strengths
            if (dataQuality.Score == dataQuality.Max)
                feedback.Strengths.Add("✅ Data quality issues: Perfect score ({0}/{0})".Replace("{0}", dataQuality.Correct.ToString()));
            
            if (fever.Score == fever.Max)
                feedback.Strengths.Add("✅ Fever patients: Perfect score ({0}/{0})".Replace("{0}", fever.Correct.ToString()));
            
            if (highRisk.Score == highRisk.Max)
                feedback.Strengths.Add("✅ High-risk patients: Perfect score ({0}/{0})".Replace("{0}", highRisk.Correct.ToString()));

            // Generate issues
            if (highRisk.Score < highRisk.Max)
            {
                if (highRisk.Matches == highRisk.Correct && highRisk.Submitted > highRisk.Correct)
                    feedback.Issues.Add($"🔄 High-risk patients: {highRisk.Matches}/{highRisk.Correct} correct, but {highRisk.Submitted - highRisk.Matches} incorrectly included");
                else if (highRisk.Matches < highRisk.Correct)
                    feedback.Issues.Add($"🔄 High-risk patients: {highRisk.Matches}/{highRisk.Correct} correct, but {highRisk.Correct - highRisk.Matches} missed");
            }

            if (fever.Score < fever.Max)
            {
                if (fever.Matches == fever.Correct && fever.Submitted > fever.Correct)
                    feedback.Issues.Add($"🔄 Fever patients: {fever.Matches}/{fever.Correct} correct, but {fever.Submitted - fever.Matches} incorrectly included");
                else if (fever.Matches < fever.Correct)
                    feedback.Issues.Add($"🔄 Fever patients: {fever.Matches}/{fever.Correct} correct, but {fever.Correct - fever.Matches} missed");
            }

            if (dataQuality.Score < dataQuality.Max)
            {
                if (dataQuality.Matches == dataQuality.Correct && dataQuality.Submitted > dataQuality.Correct)
                    feedback.Issues.Add($"🔄 Data quality issues: {dataQuality.Matches}/{dataQuality.Correct} correct, but {dataQuality.Submitted - dataQuality.Matches} incorrectly included");
                else if (dataQuality.Matches < dataQuality.Correct)
                    feedback.Issues.Add($"🔄 Data quality issues: {dataQuality.Matches}/{dataQuality.Correct} correct, but {dataQuality.Correct - dataQuality.Matches} missed");
            }

            return feedback;
        }
    }
}