using HealthcareApi.Services;
using HealthcareApi.Middleware;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();

// Register our custom services
builder.Services.AddSingleton<IPatientService, PatientService>();
builder.Services.AddSingleton<IRiskScoringService, RiskScoringService>();
builder.Services.AddSingleton<IApiKeyService, ApiKeyService>();

// Add logging
builder.Services.AddLogging(logging =>
{
    logging.ClearProviders();
    logging.AddConsole();
    logging.AddDebug();
});

// Add CORS for development
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { 
        Title = "Healthcare API", 
        Version = "v1.0",
        Description = "DemoMed Healthcare API - Assessment Implementation"
    });
    
    // Add API Key authentication to Swagger
    c.AddSecurityDefinition("ApiKey", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Description = "API Key needed to access the endpoints. x-api-key: {your-api-key}",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Name = "x-api-key",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.ApiKey
    });
    
    c.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "ApiKey"
                }
            },
            Array.Empty<string>()
        }
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Healthcare API v1.0");
        c.RoutePrefix = string.Empty; // Set Swagger UI at the app's root
    });
}

// Add CORS
app.UseCors("AllowAll");

// Add custom middleware in order
app.UseMiddleware<FailureSimulationMiddleware>();
app.UseMiddleware<ApiKeyMiddleware>();
app.UseMiddleware<RateLimitingMiddleware>();
app.UseMiddleware<InconsistentResponseMiddleware>();

// Add standard middleware
app.UseHttpsRedirection();
app.UseAuthorization();

// Add health check endpoint
app.MapGet("/health", () => new
{
    status = "healthy",
    timestamp = DateTime.UtcNow,
    version = "v1.0"
});

app.MapControllers();

// Log startup information
var logger = app.Services.GetRequiredService<ILogger<Program>>();
logger.LogInformation("Healthcare API starting up...");
logger.LogInformation("Assessment Session API Key: ak_b58ec80cb7787d5ea6caf1c375b183675f0d9bcbcfa591ec");
logger.LogInformation("Additional API Keys for testing:");
logger.LogInformation("- demo-api-key-12345");
logger.LogInformation("- test-key-67890");
logger.LogInformation("- assessment-key-abcdef");
logger.LogInformation("- healthcare-demo-key");
logger.LogInformation("API Features: Rate limiting (60/min), Failure simulation (~8%), Inconsistent responses (~15%)");

app.Run();

// Make Program class accessible for integration tests
public partial class Program { }
