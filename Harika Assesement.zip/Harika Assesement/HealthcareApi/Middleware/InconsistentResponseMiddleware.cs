using System.Text.Json;
using HealthcareApi.DTOs;
using HealthcareApi.Models;

namespace HealthcareApi.Middleware
{
    public class InconsistentResponseMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<InconsistentResponseMiddleware> _logger;
        private readonly Random _random;
        private readonly double _inconsistencyRate;

        public InconsistentResponseMiddleware(RequestDelegate next, ILogger<InconsistentResponseMiddleware> logger)
        {
            _next = next;
            _logger = logger;
            _random = new Random();
            _inconsistencyRate = 0.15; // 15% chance of inconsistent responses
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Skip inconsistency for health checks, swagger, and non-patient endpoints
            if (context.Request.Path.StartsWithSegments("/health") ||
                context.Request.Path.StartsWithSegments("/swagger") ||
                !context.Request.Path.StartsWithSegments("/api/patients"))
            {
                await _next(context);
                return;
            }

            // Capture the original response
            var originalBodyStream = context.Response.Body;
            using var responseBody = new MemoryStream();
            context.Response.Body = responseBody;

            await _next(context);

            // Check if we should introduce inconsistency
            if (_random.NextDouble() < _inconsistencyRate && context.Response.StatusCode == 200)
            {
                responseBody.Seek(0, SeekOrigin.Begin);
                var responseContent = await new StreamReader(responseBody).ReadToEndAsync();

                try
                {
                    var modifiedResponse = IntroduceInconsistency(responseContent);
                    
                    _logger.LogWarning("Introducing response inconsistency for request to {Path}", context.Request.Path);
                    
                    // Write modified response
                    context.Response.Body = originalBodyStream;
                    context.Response.ContentLength = null; // Reset content length
                    await context.Response.WriteAsync(modifiedResponse);
                    return;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error introducing response inconsistency");
                    // Fall back to original response
                }
            }

            // Write original response
            responseBody.Seek(0, SeekOrigin.Begin);
            context.Response.Body = originalBodyStream;
            await responseBody.CopyToAsync(originalBodyStream);
        }

        private string IntroduceInconsistency(string originalResponse)
        {
            try
            {
                var patientResponse = JsonSerializer.Deserialize<PatientResponse>(originalResponse, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                if (patientResponse?.Data != null)
                {
                    var inconsistencyType = _random.Next(1, 5);
                    
                    switch (inconsistencyType)
                    {
                        case 1: // Missing fields in some patients
                            return IntroduceMissingFields(patientResponse);
                        
                        case 2: // Different field names (camelCase vs PascalCase)
                            return IntroduceDifferentFieldNames(patientResponse);
                        
                        case 3: // Extra unexpected fields
                            return IntroduceExtraFields(patientResponse);
                        
                        case 4: // Different data types (string numbers)
                            return IntroduceDifferentDataTypes(patientResponse);
                        
                        default:
                            return originalResponse;
                    }
                }
            }
            catch
            {
                // If parsing fails, return original
            }

            return originalResponse;
        }

        private string IntroduceMissingFields(PatientResponse response)
        {
            // Randomly remove fields from some patients
            foreach (var patient in response.Data.Take(_random.Next(1, Math.Min(3, response.Data.Count))))
            {
                var fieldToRemove = _random.Next(1, 4);
                switch (fieldToRemove)
                {
                    case 1:
                        patient.BloodPressure = null!;
                        break;
                    case 2:
                        patient.Temperature = null;
                        break;
                    case 3:
                        patient.Medications = null!;
                        break;
                }
            }

            return JsonSerializer.Serialize(response, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
            });
        }

        private string IntroduceDifferentFieldNames(PatientResponse response)
        {
            // Create a response with different field naming
            var inconsistentData = response.Data.Select(p => new
            {
                patient_id = p.PatientId,
                full_name = p.Name,
                patient_age = p.Age,
                sex = p.Gender,
                bp_reading = p.BloodPressure,
                temp_f = p.Temperature,
                visit_dt = p.VisitDate,
                dx = p.Diagnosis,
                meds = p.Medications
            }).ToList();

            var inconsistentResponse = new
            {
                patients = inconsistentData,
                page_info = new
                {
                    current_page = response.Pagination.Page,
                    per_page = response.Pagination.Limit,
                    total_count = response.Pagination.Total,
                    page_count = response.Pagination.TotalPages,
                    has_more = response.Pagination.HasNext,
                    has_prev = response.Pagination.HasPrevious
                },
                meta = new
                {
                    ts = response.Metadata.Timestamp,
                    api_version = response.Metadata.Version,
                    req_id = response.Metadata.RequestId
                }
            };

            return JsonSerializer.Serialize(inconsistentResponse, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
        }

        private string IntroduceExtraFields(PatientResponse response)
        {
            // Add unexpected fields to the response
            var enhancedData = response.Data.Select(p => new
            {
                patientId = p.PatientId,
                name = p.Name,
                age = p.Age,
                gender = p.Gender,
                bloodPressure = p.BloodPressure,
                temperature = p.Temperature,
                visitDate = p.VisitDate,
                diagnosis = p.Diagnosis,
                medications = p.Medications,
                // Extra fields
                lastUpdated = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                dataSource = "legacy_system",
                recordVersion = _random.Next(1, 10),
                isActive = true,
                notes = _random.NextDouble() > 0.5 ? "Additional patient notes" : null
            }).ToList();

            var enhancedResponse = new
            {
                data = enhancedData,
                pagination = response.Pagination,
                metadata = response.Metadata,
                // Extra metadata
                serverInfo = new
                {
                    region = "us-east-1",
                    environment = "production",
                    buildVersion = "2.1.4"
                }
            };

            return JsonSerializer.Serialize(enhancedResponse, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
            });
        }

        private string IntroduceDifferentDataTypes(PatientResponse response)
        {
            // Convert some numeric fields to strings
            var modifiedData = response.Data.Select(p => new
            {
                patientId = p.PatientId,
                name = p.Name,
                age = p.Age?.ToString(), // Age as string
                gender = p.Gender,
                bloodPressure = p.BloodPressure,
                temperature = p.Temperature?.ToString("F1"), // Temperature as string
                visitDate = p.VisitDate,
                diagnosis = p.Diagnosis,
                medications = p.Medications
            }).ToList();

            var modifiedResponse = new
            {
                data = modifiedData,
                pagination = new
                {
                    page = response.Pagination.Page.ToString(), // Page as string
                    limit = response.Pagination.Limit.ToString(), // Limit as string
                    total = response.Pagination.Total,
                    totalPages = response.Pagination.TotalPages,
                    hasNext = response.Pagination.HasNext,
                    hasPrevious = response.Pagination.HasPrevious
                },
                metadata = response.Metadata
            };

            return JsonSerializer.Serialize(modifiedResponse, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
        }
    }
}