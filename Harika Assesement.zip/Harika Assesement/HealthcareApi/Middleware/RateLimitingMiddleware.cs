using System.Collections.Concurrent;
using System.Text.Json;

namespace HealthcareApi.Middleware
{
    public class RateLimitingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<RateLimitingMiddleware> _logger;
        private readonly ConcurrentDictionary<string, ApiKeyRateLimit> _rateLimits;
        private readonly int _requestsPerMinute;
        private readonly TimeSpan _timeWindow;

        public RateLimitingMiddleware(RequestDelegate next, ILogger<RateLimitingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
            _rateLimits = new ConcurrentDictionary<string, ApiKeyRateLimit>();
            _requestsPerMinute = 60; // Allow 60 requests per minute
            _timeWindow = TimeSpan.FromMinutes(1);
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var apiKey = context.Items["ApiKey"]?.ToString();
            if (string.IsNullOrEmpty(apiKey))
            {
                // If no API key, skip rate limiting (should be caught by auth middleware)
                await _next(context);
                return;
            }

            var rateLimit = _rateLimits.GetOrAdd(apiKey, _ => new ApiKeyRateLimit());
            var now = DateTime.UtcNow;
            bool rateLimitExceeded = false;
            int currentRequestCount = 0;

            lock (rateLimit)
            {
                // Clean old requests outside the time window
                rateLimit.Requests.RemoveAll(r => now - r > _timeWindow);

                // Check if rate limit exceeded
                if (rateLimit.Requests.Count >= _requestsPerMinute)
                {
                    rateLimitExceeded = true;
                    currentRequestCount = rateLimit.Requests.Count;
                }
                else
                {
                    // Add current request
                    rateLimit.Requests.Add(now);
                    currentRequestCount = rateLimit.Requests.Count;
                }
            }

            if (rateLimitExceeded)
            {
                _logger.LogWarning("Rate limit exceeded for API key {ApiKey}. Requests: {RequestCount}",
                    apiKey[..Math.Min(8, apiKey.Length)] + "...", currentRequestCount);
                
                await WriteRateLimitResponse(context);
                return;
            }

            _logger.LogDebug("Rate limit check passed for API key {ApiKey}. Current requests: {RequestCount}",
                apiKey[..Math.Min(8, apiKey.Length)] + "...", currentRequestCount);

            await _next(context);
        }

        private static async Task WriteRateLimitResponse(HttpContext context)
        {
            context.Response.StatusCode = 429;
            context.Response.ContentType = "application/json";

            var response = new
            {
                error = "Too Many Requests",
                message = "Rate limit exceeded. Please try again later.",
                retryAfter = 60,
                timestamp = DateTime.UtcNow
            };

            var jsonResponse = JsonSerializer.Serialize(response, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            await context.Response.WriteAsync(jsonResponse);
        }

        private class ApiKeyRateLimit
        {
            public List<DateTime> Requests { get; } = new List<DateTime>();
        }
    }
}