using System.Text.Json;

namespace HealthcareApi.Middleware
{
    public class FailureSimulationMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<FailureSimulationMiddleware> _logger;
        private readonly Random _random;
        private readonly double _failureRate;

        public FailureSimulationMiddleware(RequestDelegate next, ILogger<FailureSimulationMiddleware> logger)
        {
            _next = next;
            _logger = logger;
            _random = new Random();
            _failureRate = 0.08; // 8% failure rate as specified
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Skip failure simulation for health checks and swagger
            if (context.Request.Path.StartsWithSegments("/health") ||
                context.Request.Path.StartsWithSegments("/swagger"))
            {
                await _next(context);
                return;
            }

            // Simulate intermittent failures
            if (_random.NextDouble() < _failureRate)
            {
                var statusCode = _random.NextDouble() < 0.5 ? 500 : 503;
                var errorType = statusCode == 500 ? "Internal Server Error" : "Service Unavailable";
                
                _logger.LogWarning("Simulating {ErrorType} for request to {Path}", errorType, context.Request.Path);
                
                await WriteErrorResponse(context, statusCode, errorType);
                return;
            }

            await _next(context);
        }

        private static async Task WriteErrorResponse(HttpContext context, int statusCode, string errorType)
        {
            context.Response.StatusCode = statusCode;
            context.Response.ContentType = "application/json";

            var response = new
            {
                error = errorType,
                message = statusCode == 500 
                    ? "An internal server error occurred. Please try again later."
                    : "Service temporarily unavailable. Please retry your request.",
                timestamp = DateTime.UtcNow,
                path = context.Request.Path.Value
            };

            var jsonResponse = JsonSerializer.Serialize(response, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            await context.Response.WriteAsync(jsonResponse);
        }
    }
}