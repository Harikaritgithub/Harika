using HealthcareApi.Services;
using System.Text.Json;

namespace HealthcareApi.Middleware
{
    public class ApiKeyMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ApiKeyMiddleware> _logger;
        private const string ApiKeyHeaderName = "x-api-key";

        public ApiKeyMiddleware(RequestDelegate next, ILogger<ApiKeyMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context, IApiKeyService apiKeyService)
        {
            // Skip authentication for health checks and swagger
            if (context.Request.Path.StartsWithSegments("/health") ||
                context.Request.Path.StartsWithSegments("/swagger"))
            {
                await _next(context);
                return;
            }

            if (!context.Request.Headers.TryGetValue(ApiKeyHeaderName, out var extractedApiKey))
            {
                _logger.LogWarning("API key missing from request to {Path}", context.Request.Path);
                await WriteUnauthorizedResponse(context, "API key is missing");
                return;
            }

            var apiKey = extractedApiKey.FirstOrDefault();
            if (string.IsNullOrWhiteSpace(apiKey))
            {
                _logger.LogWarning("Empty API key provided for request to {Path}", context.Request.Path);
                await WriteUnauthorizedResponse(context, "API key is empty");
                return;
            }

            if (!apiKeyService.IsValidApiKey(apiKey))
            {
                _logger.LogWarning("Invalid API key '{ApiKey}' used for request to {Path}", 
                    apiKey[..Math.Min(8, apiKey.Length)] + "...", context.Request.Path);
                await WriteUnauthorizedResponse(context, "Invalid API key");
                return;
            }

            _logger.LogInformation("Valid API key authenticated for request to {Path}", context.Request.Path);
            
            // Store API key in context for rate limiting
            context.Items["ApiKey"] = apiKey;
            
            await _next(context);
        }

        private static async Task WriteUnauthorizedResponse(HttpContext context, string message)
        {
            context.Response.StatusCode = 401;
            context.Response.ContentType = "application/json";

            var response = new
            {
                error = "Unauthorized",
                message = message,
                timestamp = DateTime.UtcNow
            };

            var jsonResponse = JsonSerializer.Serialize(response, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            await context.Response.WriteAsync(jsonResponse);
        }
    }
}