using HealthcareApi.Models;

namespace HealthcareApi.DTOs
{
    public class PatientResponse
    {
        public List<Patient> Data { get; set; } = new List<Patient>();
        public PaginationResponse Pagination { get; set; } = new PaginationResponse();
        public MetadataResponse Metadata { get; set; } = new MetadataResponse();
    }

    public class MetadataResponse
    {
        public DateTime Timestamp { get; set; }
        public string Version { get; set; } = "v1.0";
        public string RequestId { get; set; } = string.Empty;
    }
}