namespace HealthcareApi.DTOs
{
    public class AssessmentRequest
    {
        public List<string> HighRiskPatients { get; set; } = new List<string>();
        public List<string> FeverPatients { get; set; } = new List<string>();
        public List<string> DataQualityIssues { get; set; } = new List<string>();
    }

    public class AssessmentResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public AssessmentResults Results { get; set; } = new AssessmentResults();
    }

    public class AssessmentResults
    {
        public double Score { get; set; }
        public int Percentage { get; set; }
        public string Status { get; set; } = string.Empty;
        public AssessmentBreakdown Breakdown { get; set; } = new AssessmentBreakdown();
        public AssessmentFeedback Feedback { get; set; } = new AssessmentFeedback();
        public int AttemptNumber { get; set; }
        public int RemainingAttempts { get; set; }
        public bool IsPersonalBest { get; set; }
        public bool CanResubmit { get; set; }
    }

    public class AssessmentBreakdown
    {
        public CategoryScore HighRisk { get; set; } = new CategoryScore();
        public CategoryScore Fever { get; set; } = new CategoryScore();
        public CategoryScore DataQuality { get; set; } = new CategoryScore();
    }

    public class CategoryScore
    {
        public int Score { get; set; }
        public int Max { get; set; }
        public int Correct { get; set; }
        public int Submitted { get; set; }
        public int Matches { get; set; }
    }

    public class AssessmentFeedback
    {
        public List<string> Strengths { get; set; } = new List<string>();
        public List<string> Issues { get; set; } = new List<string>();
    }
}