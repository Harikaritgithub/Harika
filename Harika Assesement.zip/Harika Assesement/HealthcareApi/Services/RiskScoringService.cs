using HealthcareApi.Models;
using System.Text.RegularExpressions;

namespace HealthcareApi.Services
{
    public class RiskScoringService : IRiskScoringService
    {
        public int CalculateBloodPressureRisk(string bloodPressure)
        {
            if (string.IsNullOrWhiteSpace(bloodPressure))
                return 0;

            // Parse blood pressure format "systolic/diastolic"
            var match = Regex.Match(bloodPressure, @"^(\d+)/(\d+)$");
            if (!match.Success)
                return 0; // Invalid format

            if (!int.TryParse(match.Groups[1].Value, out int systolic) ||
                !int.TryParse(match.Groups[2].Value, out int diastolic))
                return 0;

            // Determine risk based on higher category
            int systolicRisk = GetSystolicRisk(systolic);
            int diastolicRisk = GetDiastolicRisk(diastolic);

            return Math.Max(systolicRisk, diastolicRisk);
        }

        private int GetSystolicRisk(int systolic)
        {
            if (systolic < 120) return 1; // Normal
            if (systolic >= 120 && systolic <= 129) return 2; // Elevated
            if (systolic >= 130 && systolic <= 139) return 3; // Stage 1
            return 4; // Stage 2 (≥140)
        }

        private int GetDiastolicRisk(int diastolic)
        {
            if (diastolic < 80) return 1; // Normal
            if (diastolic >= 80 && diastolic <= 89) return 3; // Stage 1
            return 4; // Stage 2 (≥90)
        }

        public int CalculateTemperatureRisk(double? temperature)
        {
            if (!temperature.HasValue)
                return 0;

            double temp = temperature.Value;
            
            if (temp <= 99.5) return 0; // Normal
            if (temp >= 99.6 && temp <= 100.9) return 1; // Low Fever
            return 2; // High Fever (≥101.0)
        }

        public int CalculateAgeRisk(int? age)
        {
            if (!age.HasValue)
                return 0;

            int ageValue = age.Value;
            
            if (ageValue < 40) return 1; // Under 40
            if (ageValue >= 40 && ageValue <= 65) return 1; // 40-65
            return 2; // Over 65
        }

        public int CalculateTotalRisk(Patient patient)
        {
            int bpRisk = CalculateBloodPressureRisk(patient.BloodPressure);
            int tempRisk = CalculateTemperatureRisk(patient.Temperature);
            int ageRisk = CalculateAgeRisk(patient.Age);

            return bpRisk + tempRisk + ageRisk;
        }

        public bool IsHighRisk(Patient patient)
        {
            return CalculateTotalRisk(patient) >= 4;
        }

        public bool HasFever(Patient patient)
        {
            return patient.Temperature.HasValue && patient.Temperature.Value >= 99.6;
        }

        public bool HasDataQualityIssues(Patient patient)
        {
            // Check for missing or invalid blood pressure
            if (string.IsNullOrWhiteSpace(patient.BloodPressure) ||
                !Regex.IsMatch(patient.BloodPressure, @"^(\d+)/(\d+)$"))
                return true;

            // Check for missing or invalid temperature
            if (!patient.Temperature.HasValue)
                return true;

            // Check for missing or invalid age
            if (!patient.Age.HasValue)
                return true;

            return false;
        }
    }
}