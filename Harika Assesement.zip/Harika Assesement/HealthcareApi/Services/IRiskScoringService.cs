using HealthcareApi.Models;

namespace HealthcareApi.Services
{
    public interface IRiskScoringService
    {
        int CalculateBloodPressureRisk(string bloodPressure);
        int CalculateTemperatureRisk(double? temperature);
        int CalculateAgeRisk(int? age);
        int CalculateTotalRisk(Patient patient);
        bool IsHighRisk(Patient patient);
        bool HasFever(Patient patient);
        bool HasDataQualityIssues(Patient patient);
    }
}