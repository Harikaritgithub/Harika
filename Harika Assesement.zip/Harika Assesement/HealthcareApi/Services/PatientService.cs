using HealthcareApi.Models;
using HealthcareApi.DTOs;

namespace HealthcareApi.Services
{
    public class PatientService : IPatientService
    {
        private readonly List<Patient> _patients;

        public PatientService()
        {
            _patients = GenerateMockPatients();
        }

        public async Task<PatientResponse> GetPatientsAsync(int page = 1, int limit = 5)
        {
            // Simulate async operation
            await Task.Delay(10);

            // Validate parameters
            page = Math.Max(1, page);
            limit = Math.Max(1, Math.Min(20, limit)); // Max 20 per page

            var totalPatients = _patients.Count;
            var totalPages = (int)Math.Ceiling((double)totalPatients / limit);
            var skip = (page - 1) * limit;

            var paginatedPatients = _patients
                .Skip(skip)
                .Take(limit)
                .ToList();

            return new PatientResponse
            {
                Data = paginatedPatients,
                Pagination = new PaginationResponse
                {
                    Page = page,
                    Limit = limit,
                    Total = totalPatients,
                    TotalPages = totalPages,
                    HasNext = page < totalPages,
                    HasPrevious = page > 1
                },
                Metadata = new MetadataResponse
                {
                    Timestamp = DateTime.UtcNow,
                    Version = "v1.0",
                    RequestId = Guid.NewGuid().ToString("N")[..8]
                }
            };
        }

        public async Task<List<Patient>> GetAllPatientsAsync()
        {
            await Task.Delay(10);
            return _patients.ToList();
        }

        public async Task<Patient?> GetPatientByIdAsync(string patientId)
        {
            await Task.Delay(10);
            return _patients.FirstOrDefault(p => p.PatientId == patientId);
        }

        private List<Patient> GenerateMockPatients()
        {
            return new List<Patient>
            {
                // Normal patients
                new Patient { PatientId = "DEMO001", Name = "TestPatient, John", Age = 45, Gender = "M", BloodPressure = "120/80", Temperature = 98.6, VisitDate = "2024-01-15", Diagnosis = "Sample_Hypertension", Medications = "DemoMed_A 10mg, TestDrug_B 500mg" },
                new Patient { PatientId = "DEMO003", Name = "MockUser, Alice", Age = 32, Gender = "F", BloodPressure = "115/75", Temperature = 98.4, VisitDate = "2024-01-17", Diagnosis = "Routine_Checkup", Medications = "None" },
                new Patient { PatientId = "DEMO006", Name = "SamplePatient, Bob", Age = 28, Gender = "M", BloodPressure = "118/78", Temperature = 99.1, VisitDate = "2024-01-20", Diagnosis = "TestCondition_A", Medications = "MockMed_C 250mg" },
                
                // High-risk patients (total risk >= 4)
                new Patient { PatientId = "DEMO002", Name = "AssessmentUser, Jane", Age = 67, Gender = "F", BloodPressure = "140/90", Temperature = 99.2, VisitDate = "2024-01-16", Diagnosis = "Eval_Diabetes", Medications = "FakeMed 1000mg" }, // BP:4 + Temp:0 + Age:2 = 6
                new Patient { PatientId = "DEMO031", Name = "HighRisk, Charlie", Age = 72, Gender = "M", BloodPressure = "145/95", Temperature = 98.8, VisitDate = "2024-02-10", Diagnosis = "Severe_Hypertension", Medications = "TestMed_X 50mg" }, // BP:4 + Temp:0 + Age:2 = 6
                new Patient { PatientId = "DEMO015", Name = "Critical, David", Age = 55, Gender = "M", BloodPressure = "135/85", Temperature = 100.2, VisitDate = "2024-01-25", Diagnosis = "Stage1_HTN", Medications = "DemoMed_B 25mg" }, // BP:3 + Temp:1 + Age:1 = 5
                new Patient { PatientId = "DEMO022", Name = "Urgent, Emma", Age = 68, Gender = "F", BloodPressure = "132/82", Temperature = 98.9, VisitDate = "2024-02-01", Diagnosis = "Hypertension_Stage1", Medications = "TestDrug_Y 100mg" }, // BP:3 + Temp:0 + Age:2 = 5
                
                // Fever patients (temperature >= 99.6)
                new Patient { PatientId = "DEMO005", Name = "FeverPatient, Frank", Age = 41, Gender = "M", BloodPressure = "125/82", Temperature = 100.1, VisitDate = "2024-01-19", Diagnosis = "Flu_Symptoms", Medications = "Acetaminophen 500mg" },
                new Patient { PatientId = "DEMO021", Name = "Febrile, Grace", Age = 29, Gender = "F", BloodPressure = "110/70", Temperature = 101.3, VisitDate = "2024-01-30", Diagnosis = "Upper_Respiratory", Medications = "Ibuprofen 400mg" },
                new Patient { PatientId = "DEMO012", Name = "Pyrexia, Henry", Age = 35, Gender = "M", BloodPressure = "122/79", Temperature = 99.8, VisitDate = "2024-01-23", Diagnosis = "Viral_Infection", Medications = "Tylenol 650mg" },
                new Patient { PatientId = "DEMO018", Name = "Hyperthermia, Ivy", Age = 26, Gender = "F", BloodPressure = "108/68", Temperature = 100.7, VisitDate = "2024-01-28", Diagnosis = "Bacterial_Infection", Medications = "Amoxicillin 875mg" },
                
                // Data quality issues
                new Patient { PatientId = "DEMO004", Name = "InvalidBP, Jack", Age = 50, Gender = "M", BloodPressure = "INVALID", Temperature = 98.7, VisitDate = "2024-01-18", Diagnosis = "Data_Error", Medications = "Unknown" },
                new Patient { PatientId = "DEMO007", Name = "MissingTemp, Kate", Age = 44, Gender = "F", BloodPressure = "128/84", Temperature = null, VisitDate = "2024-01-21", Diagnosis = "Incomplete_Record", Medications = "TestMed_Z 75mg" },
                new Patient { PatientId = "DEMO009", Name = "NoAge, Leo", Age = null, Gender = "M", BloodPressure = "119/77", Temperature = 98.5, VisitDate = "2024-01-22", Diagnosis = "Missing_Demographics", Medications = "DemoMed_D 200mg" },
                new Patient { PatientId = "DEMO013", Name = "PartialBP, Mia", Age = 38, Gender = "F", BloodPressure = "130/", Temperature = 99.0, VisitDate = "2024-01-24", Diagnosis = "Incomplete_Vitals", Medications = "MockMed_E 150mg" },
                new Patient { PatientId = "DEMO017", Name = "EmptyBP, Noah", Age = 42, Gender = "M", BloodPressure = "", Temperature = 98.3, VisitDate = "2024-01-27", Diagnosis = "Data_Missing", Medications = "TestDrug_F 300mg" },
                new Patient { PatientId = "DEMO024", Name = "BadFormat, Olivia", Age = 33, Gender = "F", BloodPressure = "120-80", Temperature = 98.9, VisitDate = "2024-02-03", Diagnosis = "Format_Error", Medications = "DemoMed_G 400mg" },
                new Patient { PatientId = "DEMO027", Name = "InvalidTemp, Paul", Age = 47, Gender = "M", BloodPressure = "124/81", Temperature = null, VisitDate = "2024-02-06", Diagnosis = "Sensor_Error", Medications = "MockMed_H 600mg" },
                new Patient { PatientId = "DEMO030", Name = "MissingAge, Quinn", Age = null, Gender = "F", BloodPressure = "117/73", Temperature = 98.8, VisitDate = "2024-02-09", Diagnosis = "Demographic_Missing", Medications = "TestMed_I 800mg" },
                
                // Additional normal patients to reach ~50 total
                new Patient { PatientId = "DEMO008", Name = "Normal, Rachel", Age = 31, Gender = "F", BloodPressure = "112/74", Temperature = 98.2, VisitDate = "2024-01-21", Diagnosis = "Wellness_Check", Medications = "Vitamins" },
                new Patient { PatientId = "DEMO010", Name = "Healthy, Sam", Age = 39, Gender = "M", BloodPressure = "116/76", Temperature = 98.6, VisitDate = "2024-01-22", Diagnosis = "Annual_Physical", Medications = "None" },
                new Patient { PatientId = "DEMO011", Name = "Routine, Tina", Age = 27, Gender = "F", BloodPressure = "114/72", Temperature = 98.4, VisitDate = "2024-01-23", Diagnosis = "Preventive_Care", Medications = "Birth_Control" },
                new Patient { PatientId = "DEMO014", Name = "Standard, Uma", Age = 36, Gender = "F", BloodPressure = "121/79", Temperature = 98.7, VisitDate = "2024-01-25", Diagnosis = "Follow_Up", Medications = "Aspirin 81mg" },
                new Patient { PatientId = "DEMO016", Name = "Regular, Victor", Age = 43, Gender = "M", BloodPressure = "119/77", Temperature = 98.5, VisitDate = "2024-01-26", Diagnosis = "Monitoring", Medications = "Statin 20mg" },
                new Patient { PatientId = "DEMO019", Name = "Typical, Wendy", Age = 30, Gender = "F", BloodPressure = "113/71", Temperature = 98.3, VisitDate = "2024-01-29", Diagnosis = "Screening", Medications = "Multivitamin" },
                new Patient { PatientId = "DEMO020", Name = "Average, Xavier", Age = 34, Gender = "M", BloodPressure = "118/75", Temperature = 98.8, VisitDate = "2024-01-30", Diagnosis = "Check_Up", Medications = "Omega3" },
                new Patient { PatientId = "DEMO023", Name = "Common, Yara", Age = 25, Gender = "F", BloodPressure = "109/69", Temperature = 98.1, VisitDate = "2024-02-02", Diagnosis = "Wellness", Medications = "Calcium" },
                new Patient { PatientId = "DEMO025", Name = "Basic, Zach", Age = 37, Gender = "M", BloodPressure = "123/80", Temperature = 98.9, VisitDate = "2024-02-04", Diagnosis = "Routine", Medications = "Vitamin_D" },
                new Patient { PatientId = "DEMO026", Name = "Simple, Amy", Age = 29, Gender = "F", BloodPressure = "111/73", Temperature = 98.2, VisitDate = "2024-02-05", Diagnosis = "Physical", Medications = "Iron_Supplement" },
                new Patient { PatientId = "DEMO028", Name = "Plain, Ben", Age = 40, Gender = "M", BloodPressure = "120/78", Temperature = 98.6, VisitDate = "2024-02-07", Diagnosis = "Annual_Exam", Medications = "Probiotics" },
                new Patient { PatientId = "DEMO029", Name = "Ordinary, Cara", Age = 33, Gender = "F", BloodPressure = "115/74", Temperature = 98.4, VisitDate = "2024-02-08", Diagnosis = "Health_Maintenance", Medications = "Magnesium" },
                new Patient { PatientId = "DEMO032", Name = "Standard, Dan", Age = 46, Gender = "M", BloodPressure = "117/76", Temperature = 98.7, VisitDate = "2024-02-11", Diagnosis = "Preventive", Medications = "CoQ10" },
                new Patient { PatientId = "DEMO033", Name = "Normal, Eve", Age = 28, Gender = "F", BloodPressure = "112/70", Temperature = 98.3, VisitDate = "2024-02-12", Diagnosis = "Screening", Medications = "Folic_Acid" },
                new Patient { PatientId = "DEMO034", Name = "Regular, Fred", Age = 35, Gender = "M", BloodPressure = "119/77", Temperature = 98.8, VisitDate = "2024-02-13", Diagnosis = "Check_Up", Medications = "B_Complex" },
                new Patient { PatientId = "DEMO035", Name = "Typical, Gina", Age = 32, Gender = "F", BloodPressure = "114/72", Temperature = 98.1, VisitDate = "2024-02-14", Diagnosis = "Wellness", Medications = "Zinc" },
                new Patient { PatientId = "DEMO036", Name = "Average, Hank", Age = 41, Gender = "M", BloodPressure = "121/79", Temperature = 98.5, VisitDate = "2024-02-15", Diagnosis = "Routine", Medications = "Selenium" },
                new Patient { PatientId = "DEMO037", Name = "Common, Iris", Age = 26, Gender = "F", BloodPressure = "108/68", Temperature = 98.2, VisitDate = "2024-02-16", Diagnosis = "Physical", Medications = "Biotin" },
                new Patient { PatientId = "DEMO038", Name = "Basic, Jake", Age = 38, Gender = "M", BloodPressure = "122/80", Temperature = 98.9, VisitDate = "2024-02-17", Diagnosis = "Annual", Medications = "Chromium" },
                new Patient { PatientId = "DEMO039", Name = "Simple, Kim", Age = 31, Gender = "F", BloodPressure = "113/71", Temperature = 98.4, VisitDate = "2024-02-18", Diagnosis = "Health_Check", Medications = "Turmeric" },
                new Patient { PatientId = "DEMO040", Name = "Plain, Luke", Age = 44, Gender = "M", BloodPressure = "118/75", Temperature = 98.6, VisitDate = "2024-02-19", Diagnosis = "Monitoring", Medications = "Ginseng" },
                new Patient { PatientId = "DEMO041", Name = "Ordinary, Maya", Age = 27, Gender = "F", BloodPressure = "110/70", Temperature = 98.3, VisitDate = "2024-02-20", Diagnosis = "Preventive", Medications = "Echinacea" },
                new Patient { PatientId = "DEMO042", Name = "Standard, Nick", Age = 39, Gender = "M", BloodPressure = "116/74", Temperature = 98.7, VisitDate = "2024-02-21", Diagnosis = "Follow_Up", Medications = "Garlic_Extract" },
                new Patient { PatientId = "DEMO043", Name = "Normal, Ola", Age = 30, Gender = "F", BloodPressure = "111/69", Temperature = 98.1, VisitDate = "2024-02-22", Diagnosis = "Screening", Medications = "Green_Tea" },
                new Patient { PatientId = "DEMO044", Name = "Regular, Pete", Age = 36, Gender = "M", BloodPressure = "119/76", Temperature = 98.8, VisitDate = "2024-02-23", Diagnosis = "Check_Up", Medications = "Milk_Thistle" },
                new Patient { PatientId = "DEMO045", Name = "Typical, Quin", Age = 33, Gender = "F", BloodPressure = "115/73", Temperature = 98.2, VisitDate = "2024-02-24", Diagnosis = "Wellness", Medications = "Saw_Palmetto" },
                new Patient { PatientId = "DEMO046", Name = "Average, Ray", Age = 42, Gender = "M", BloodPressure = "120/78", Temperature = 98.5, VisitDate = "2024-02-25", Diagnosis = "Routine", Medications = "Valerian" },
                new Patient { PatientId = "DEMO047", Name = "Common, Sue", Age = 29, Gender = "F", BloodPressure = "112/71", Temperature = 98.4, VisitDate = "2024-02-26", Diagnosis = "Physical", Medications = "Melatonin" },
                new Patient { PatientId = "DEMO048", Name = "Basic, Tom", Age = 37, Gender = "M", BloodPressure = "117/75", Temperature = 98.9, VisitDate = "2024-02-27", Diagnosis = "Annual", Medications = "Ashwagandha" },
                new Patient { PatientId = "DEMO049", Name = "Simple, Una", Age = 34, Gender = "F", BloodPressure = "114/72", Temperature = 98.3, VisitDate = "2024-02-28", Diagnosis = "Health_Check", Medications = "Rhodiola" },
                new Patient { PatientId = "DEMO050", Name = "Plain, Vince", Age = 45, Gender = "M", BloodPressure = "121/79", Temperature = 98.6, VisitDate = "2024-03-01", Diagnosis = "Monitoring", Medications = "Ginkgo_Biloba" }
            };
        }
    }
}