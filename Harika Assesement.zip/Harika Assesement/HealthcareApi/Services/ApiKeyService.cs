namespace HealthcareApi.Services
{
    public class ApiKeyService : IApiKeyService
    {
        private readonly HashSet<string> _validApiKeys;

        public ApiKeyService()
        {
            _validApiKeys = new HashSet<string>
            {
                "ak_b58ec80cb7787d5ea6caf1c375b183675f0d9bcbcfa591ec", // Assessment session key
                "demo-api-key-12345",
                "test-key-67890",
                "assessment-key-abcdef",
                "healthcare-demo-key"
            };
        }

        public bool IsValidApiKey(string apiKey)
        {
            if (string.IsNullOrWhiteSpace(apiKey))
                return false;

            return _validApiKeys.Contains(apiKey);
        }

        public string GenerateApiKey()
        {
            return $"demo-{Guid.NewGuid():N}"[..20];
        }
    }
}