using HealthcareApi.Models;
using HealthcareApi.DTOs;

namespace HealthcareApi.Services
{
    public interface IPatientService
    {
        Task<PatientResponse> GetPatientsAsync(int page = 1, int limit = 5);
        Task<List<Patient>> GetAllPatientsAsync();
        Task<Patient?> GetPatientByIdAsync(string patientId);
    }
}