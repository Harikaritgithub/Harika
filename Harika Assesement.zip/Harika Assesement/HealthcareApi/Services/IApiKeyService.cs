namespace HealthcareApi.Services
{
    public interface IApiKeyService
    {
        bool IsValidApiKey(string apiKey);
        string GenerateApiKey();
    }
}