# Healthcare API - .NET 6 Implementation

A comprehensive .NET 6 Web API implementation that replicates the DemoMed Healthcare API functionality for patient risk assessment and data management.

## 🏗️ Architecture Overview

This API implements a healthcare assessment system with the following key features:

- **Patient Data Management** - In-memory storage with 50+ mock patient records
- **Risk Scoring System** - Calculates patient risk based on blood pressure, temperature, and age
- **API Key Authentication** - Secure access control using x-api-key headers
- **Rate Limiting** - Prevents API abuse with configurable request limits
- **Failure Simulation** - Mimics real-world API behavior with intermittent failures
- **Comprehensive Testing** - 76+ unit and integration tests with 100% pass rate

## 🚀 Quick Start

### Prerequisites

- .NET 6.0 SDK or later
- Visual Studio 2022 or VS Code (optional)

### Installation & Setup

1. **Clone and Build**
   ```bash
   git clone <repository-url>
   cd HealthcareApi
   dotnet build
   ```

2. **Run the API**
   ```bash
   cd HealthcareApi
   dotnet run
   ```

3. **Access the API**
   - API Base URL: `https://localhost:7000` or `http://localhost:5000`
   - Swagger UI: `https://localhost:7000` (root path)
   - Health Check: `https://localhost:7000/health`

### API Keys for Testing

**Assessment Session API Key:**
- `ak_b58ec80cb7787d5ea6caf1c375b183675f0d9bcbcfa591ec` (Primary assessment key)

**Additional API Keys for testing:**
- `demo-api-key-12345`
- `test-key-67890`
- `assessment-key-abcdef`
- `healthcare-demo-key`

## 📋 API Endpoints

### 1. Get Patients

**GET** `/api/patients`

Retrieve paginated patient data with metadata.

**Headers:**
```
x-api-key: demo-api-key-12345
```

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 5, max: 20)

**Example Request:**
```bash
curl -X GET "https://localhost:7000/api/patients?page=1&limit=10" \
  -H "x-api-key: ak_b58ec80cb7787d5ea6caf1c375b183675f0d9bcbcfa591ec"
```

**Example Response:**
```json
{
  "data": [
    {
      "patientId": "DEMO001",
      "name": "TestPatient, John",
      "age": 45,
      "gender": "M",
      "bloodPressure": "120/80",
      "temperature": 98.6,
      "visitDate": "2024-01-15",
      "diagnosis": "Sample_Hypertension",
      "medications": "DemoMed_A 10mg, TestDrug_B 500mg"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 50,
    "totalPages": 5,
    "hasNext": true,
    "hasPrevious": false
  },
  "metadata": {
    "timestamp": "2024-01-20T10:30:00Z",
    "version": "v1.0",
    "requestId": "abc12345"
  }
}
```

### 2. Submit Assessment

**POST** `/api/submit-assessment`

Submit patient risk assessment results for scoring.

**Headers:**
```
x-api-key: demo-api-key-12345
Content-Type: application/json
```

**Request Body:**
```json
{
  "highRiskPatients": ["DEMO002", "DEMO031"],
  "feverPatients": ["DEMO005", "DEMO021"],
  "dataQualityIssues": ["DEMO004", "DEMO007"]
}
```

**Example Request:**
```bash
curl -X POST "https://localhost:7000/api/submit-assessment" \
  -H "x-api-key: ak_b58ec80cb7787d5ea6caf1c375b183675f0d9bcbcfa591ec" \
  -H "Content-Type: application/json" \
  -d '{
    "highRiskPatients": ["DEMO002", "DEMO031"],
    "feverPatients": ["DEMO005", "DEMO021"],
    "dataQualityIssues": ["DEMO004", "DEMO007"]
  }'
```

**Example Response:**
```json
{
  "success": true,
  "message": "Assessment submitted successfully",
  "results": {
    "score": 91.94,
    "percentage": 92,
    "status": "PASS",
    "breakdown": {
      "highRisk": {
        "score": 48,
        "max": 50,
        "correct": 20,
        "submitted": 21,
        "matches": 20
      },
      "fever": {
        "score": 19,
        "max": 25,
        "correct": 9,
        "submitted": 7,
        "matches": 7
      },
      "dataQuality": {
        "score": 25,
        "max": 25,
        "correct": 8,
        "submitted": 8,
        "matches": 8
      }
    },
    "feedback": {
      "strengths": [
        "✅ Data quality issues: Perfect score (8/8)"
      ],
      "issues": [
        "🔄 High-risk patients: 20/20 correct, but 1 incorrectly included"
      ]
    },
    "attemptNumber": 1,
    "remainingAttempts": 2,
    "isPersonalBest": true,
    "canResubmit": true
  }
}
```

## 🎯 Risk Scoring System

### Blood Pressure Risk Scoring

| Category | Systolic (mmHg) | Diastolic (mmHg) | Risk Score |
|----------|----------------|------------------|------------|
| Normal | <120 | AND <80 | 1 point |
| Elevated | 120-129 | AND <80 | 2 points |
| Stage 1 | 130-139 | OR 80-89 | 3 points |
| Stage 2 | ≥140 | OR ≥90 | 4 points |
| Invalid/Missing | - | - | 0 points |

**Note:** If systolic and diastolic readings fall into different categories, the higher risk score is used.

### Temperature Risk Scoring

| Category | Temperature (°F) | Risk Score |
|----------|------------------|------------|
| Normal | ≤99.5 | 0 points |
| Low Fever | 99.6-100.9 | 1 point |
| High Fever | ≥101.0 | 2 points |
| Invalid/Missing | - | 0 points |

### Age Risk Scoring

| Category | Age Range | Risk Score |
|----------|-----------|------------|
| Under 40 | <40 years | 1 point |
| 40-65 | 40-65 years | 1 point |
| Over 65 | >65 years | 2 points |
| Invalid/Missing | - | 0 points |

### Total Risk Calculation

**Total Risk Score = Blood Pressure Score + Temperature Score + Age Score**

- **High Risk**: Total score ≥ 4
- **Fever Patient**: Temperature ≥ 99.6°F
- **Data Quality Issues**: Missing or invalid BP, temperature, or age data

## 🔧 API Behavior & Features

### Authentication
- All endpoints (except `/health` and Swagger) require the `x-api-key` header
- Invalid or missing API keys return `401 Unauthorized`

### Rate Limiting
- 60 requests per minute per API key
- Exceeded limits return `429 Too Many Requests`
- Automatic cleanup of old request tracking data

### Failure Simulation
- ~8% chance of returning `500 Internal Server Error` or `503 Service Unavailable`
- Simulates real-world API reliability challenges
- Excludes health checks and Swagger endpoints

### Error Handling
- Comprehensive error responses with timestamps
- Detailed logging for debugging and monitoring
- Graceful handling of invalid input data

## 🧪 Testing

The project includes comprehensive test coverage:

### Running Tests

```bash
# Run all tests
dotnet test

# Run with detailed output
dotnet test --verbosity normal

# Run specific test project
dotnet test HealthcareApi.Tests/HealthcareApi.Tests.csproj
```

### Test Coverage

- **76+ Total Tests** with 100% pass rate
- **Unit Tests**: Risk scoring, patient service, middleware components
- **Integration Tests**: End-to-end API endpoint testing
- **Edge Case Testing**: Invalid data, boundary conditions, error scenarios

### Test Categories

1. **Risk Scoring Service Tests** (50+ tests)
   - Blood pressure risk calculations
   - Temperature risk assessments
   - Age-based risk scoring
   - Data quality validation
   - Edge cases and boundary conditions

2. **Patient Service Tests** (20+ tests)
   - Pagination functionality
   - Data retrieval and filtering
   - Performance validation
   - Mock data consistency

3. **Integration Tests** (6+ tests)
   - API authentication flows
   - End-to-end request/response validation
   - Error handling verification

## 📁 Project Structure

```
HealthcareApi/
├── HealthcareApi/                 # Main API project
│   ├── Controllers/               # API controllers
│   │   ├── PatientsController.cs
│   │   └── AssessmentController.cs
│   ├── Services/                  # Business logic services
│   │   ├── PatientService.cs
│   │   ├── RiskScoringService.cs
│   │   └── ApiKeyService.cs
│   ├── Middleware/                # Custom middleware
│   │   ├── ApiKeyMiddleware.cs
│   │   ├── RateLimitingMiddleware.cs
│   │   └── FailureSimulationMiddleware.cs
│   ├── Models/                    # Data models
│   │   └── Patient.cs
│   ├── DTOs/                      # Data transfer objects
│   │   ├── PatientResponse.cs
│   │   ├── AssessmentRequest.cs
│   │   └── PaginationResponse.cs
│   └── Program.cs                 # Application entry point
├── HealthcareApi.Tests/           # Test project
│   ├── Services/                  # Service unit tests
│   ├── Controllers/               # Controller tests
│   ├── Middleware/                # Middleware tests
│   └── Integration/               # Integration tests
└── README.md                      # This documentation
```

## 🔍 Mock Data

The API includes 50 carefully crafted mock patient records designed for testing:

- **Normal Patients**: Standard health metrics for baseline testing
- **High-Risk Patients**: Patients with risk scores ≥ 4 for alert testing
- **Fever Patients**: Patients with temperatures ≥ 99.6°F
- **Data Quality Issues**: Patients with missing/invalid data for error handling

### Sample Patient Records

```json
{
  "patientId": "DEMO002",
  "name": "AssessmentUser, Jane",
  "age": 67,
  "gender": "F",
  "bloodPressure": "140/90",
  "temperature": 99.2,
  "visitDate": "2024-01-16",
  "diagnosis": "Eval_Diabetes",
  "medications": "FakeMed 1000mg"
}
```

## 🚨 Error Responses

### 401 Unauthorized
```json
{
  "error": "Unauthorized",
  "message": "API key is missing",
  "timestamp": "2024-01-20T10:30:00Z"
}
```

### 429 Too Many Requests
```json
{
  "error": "Too Many Requests",
  "message": "Rate limit exceeded. Please try again later.",
  "retryAfter": 60,
  "timestamp": "2024-01-20T10:30:00Z"
}
```

### 500 Internal Server Error
```json
{
  "error": "Internal Server Error",
  "message": "An internal server error occurred. Please try again later.",
  "timestamp": "2024-01-20T10:30:00Z",
  "path": "/api/patients"
}
```

## 🛠️ Development

### Adding New Features

1. **Services**: Add business logic in the `Services/` directory
2. **Controllers**: Create new endpoints in `Controllers/`
3. **Middleware**: Add custom middleware in `Middleware/`
4. **Tests**: Always include corresponding tests in `HealthcareApi.Tests/`

### Configuration

Key configuration options in [`Program.cs`](HealthcareApi/Program.cs:1):

- **Rate Limiting**: Modify request limits and time windows
- **API Keys**: Add/remove valid API keys
- **Failure Rate**: Adjust intermittent failure percentage
- **Logging**: Configure log levels and providers

## 📊 Performance

- **Response Times**: <100ms for typical requests
- **Memory Usage**: Optimized in-memory data structures
- **Concurrency**: Thread-safe middleware and services
- **Scalability**: Stateless design for horizontal scaling

## 🔒 Security Features

- **API Key Authentication**: Secure access control
- **Rate Limiting**: DDoS protection
- **Input Validation**: Prevents injection attacks
- **Error Handling**: No sensitive data exposure
- **CORS Configuration**: Controlled cross-origin access

## 📝 License

This project is created for assessment purposes and demonstrates healthcare API implementation patterns using .NET 6.

---

**Note**: This is a demonstration API with simulated data created specifically for coding assessment purposes. All patient data is fictional and generated for testing scenarios.